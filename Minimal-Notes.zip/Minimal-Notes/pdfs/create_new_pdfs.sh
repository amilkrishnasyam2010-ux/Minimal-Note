#!/bin/bash

# Function to create a placeholder PDF text file
create_placeholder() {
  local filename="$1"
  echo "PLACEHOLDER PDF: $filename" > "$filename"
  echo "" >> "$filename"
  echo "This is a placeholder file." >> "$filename"
  echo "Replace this with your actual PDF file." >> "$filename"
  echo "" >> "$filename"
  echo "File: $filename" >> "$filename"
  echo "Created: $(date)" >> "$filename"
}

# Maths chapters 8-13 (Notes)
for i in {8..13}; do
  create_placeholder "Maths_${i}.pdf"
done

# Maths chapters 8-13 (Question Bank)
for i in {8..13}; do
  create_placeholder "Maths_${i}_QB.pdf"
done

# Maths chapters 8-13 (One Word)
for i in {8..13}; do
  create_placeholder "Maths_${i}_OW.pdf"
done

echo "Created new Maths chapter placeholders (8-13)"
ls -1 Maths_*.pdf | wc -l
echo "total Maths PDF files"
